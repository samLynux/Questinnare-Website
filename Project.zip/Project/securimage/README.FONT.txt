AHGBold.ttf is used by Securimage under the following license:

Alte Haas Grotesk is a typeface that look like an helvetica printed in an old Muller-Brockmann Book.

These fonts are freeware and can be distributed as long as they are
together with this text file. 

I would appreciate very much to see what you have done with it anyway.

yann le coroller 
www.yannlecoroller.com
yann@lecoroller.com